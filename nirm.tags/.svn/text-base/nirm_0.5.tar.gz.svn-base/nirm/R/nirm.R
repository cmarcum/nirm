####################################################################################
####################################################################################
##                        Network Inductive Reasoning Model                       ##
##                                                                                ##
## Model Code Written by Raffael Vardavas (vardavas@rand.org)                     ##
## R-Package Authored by Christopher Steven Marcum (cmarcum@rand.org)             ##
## Package Maintained by Christopher Steven Marcum (cmarcum@rand.org)             ##
## Last Modified on 16 January 2012                                               ##
##                                                                                ##
## Part of the nirm package for R                                                 ##
## Compile with R CMD BATCH compile.nirm.R                                        ##
## WARNING: Contains Hooks. Read compile.nirm.R header before editing.            ##
##                                                                                ##
####################################################################################
####################################################################################

nirm<-function(network.model=c("Erdos","Watts","NW.Watts","Barabasi","Empirical"),
               N=10^3,M=20,behavioral.model="Simple_Personal",enet=NULL,usbm=NULL,
               hyper.params=list(model=c(b0=5/6,B0=5/6,gamma=1/3,iip=.02,eff=1,tfs=300,s.mem=.7),vattr=cbind(V=rep(0,N),w=rep(0.3,N),inf.nn=rep(0,N),vacc.nn=rep(0,N))),
               added.RMCN=FALSE, output.dir="",save.model=TRUE,verbose=FALSE,seed=NULL){
   #First, a bunch of user input checks:
   if(!any(network.model%in%c("Erdos","Watts","NS.Watts","Barabasi","Empirical"))){stop("Invalid Network Model. See help(\"nirm\") for details.")}
   network.model<-network.model[1]
   if(network.model=="Empirical" & is.null(enet)){stop("You say you want to use an empirical network, yet your enet object is NULL.")}
   if(network.model!="Empirical" & !is.null(enet)){stop("You say you want to use a theoretical network, yet your enet object is non-NULL.")}
   if(output.dir==""){warning("You have not specified an output directory. Using present working directory; I hope you have enough free-memory here.")} 

   #Set the top environment
   nirm.env<-environment()   

   #Set seed if necessary
   if(!is.null(seed)){set.seed(seed)}

   #initialize params and placeholders
   ave.degree<-M
   attributes.data<-as.data.frame(hyper.params$vattr)
   big.beta.pref<-hyper.params$model["b0"]   
   big.beta.pop<-hyper.params$model["B0"]
   gamma<-hyper.params$model["gamma"]

   R0.pref<-big.beta.pref/gamma
   R0.beta.pop<-big.beta.pop/gamma

   initial.inf.prop<-hyper.params$model["iip"]
   eff<-hyper.params$model["eff"]
   total.flu.seasons<-hyper.params$model["tfs"]
   s.mem<-hyper.params$model["s.mem"]

   names.outcomes <- c("VaccInf","Vacc","Inf","UnInf")
   names.evaluation.levels <- c("Personal",
                             "Local.Inf","Local.Vacc",
                             "Global.Inf","Global.Vacc")

   behavioral.weights <- matrix(0,nrow=length(names.outcomes),
                             ncol=length(names.evaluation.levels), dimnames=
                             list(names.outcomes,names.evaluation.levels))
   
   Stiffness<-rep(0,length(names.outcomes))  
   names(Stiffness)<-names.outcomes  
   Personal.Delta<-rep(0,length(names.outcomes))  
   names(Personal.Delta)<-names.outcomes
   Behavioral.Model<-behavioral.model
   Pop.Samp <- list(NULL)
   flu.season<-1
   
   #Reset params if user supplied network is valid
   if(network.model=="Empirical"){
      if(is.directed(enet)){stop("This appears to be a directed network. Please supply an undirected one.")}
      N<-vcount(enet)
      M<-ecount(enet) #possibly used at a later date
      ave.degree<-ceiling(mean(degree(enet)))
      g.PTN<-enet
      g.PTN <- simplify(g.PTN)

      g.PTN <- Initialize.All.Vertex.Attributes(g.PTN, attributes.data)
      g <- g.PTN
      model<-network.model

      #list of nearest neighbours (nn) on the static Social Network. 
      nn.list.PTN <- get.nn.list.of.SN(g.PTN)
      N.nn <- degree(g.PTN)
      phi<-NA
     #Save the PTN in an R object - for post analysis.
     save(g,N,phi,nn.list.PTN, file = paste(output.dir,model,"_N",as.character(log(N,10)),".RData",sep=""))
   }

   #Finalize vector of initial model parameterize to pass to other methods 
   params.of.model<-c(N=N,initial.inf.prop=initial.inf.prop,big.beta.pref=big.beta.pref,
                     big.beta.pop=big.beta.pop,gamma=gamma,total.flu.seasons=total.flu.seasons,
                     eff=eff,added.RMCN=added.RMCN)

   #Methods for other network models
   if(network.model!="Empirical"){
      if(network.model=="Erdos"){model<-"erdos.renyi.game"}
      if(network.model=="Watts"){model<-"watts.strogatz.game"}
      if(network.model=="NW.Watts"){model<-"NW.watts.strogatz.game"}
      if(network.model=="Barabasi"){model<-"barabasi.game"}
      #PTN FILE HERE

#############################################################
###                                                       ###
###        CONSTRUCT SOCIAL CONTACT NETWORKS              ###
###                                                       ###
#############################################################

if(verbose) print(":: CONSTRUCT SOCIAL CONTACT NETWORKS ::")

if(file.exists(network.file.name)){
  load(file = network.file.name) 
  
  if(round(mean(degree(g)),0)!=ave.degree) stop("ave.degree mismatch in loading: see Construct_PTN.R")
  
}else{
### set initial nodes attributes
#I moved this to the Flu_model_frontend.R file, please do not uncomment --- CSM 11 Jan 12
#attributes.data <- as.data.frame(cbind(V=rep(0,N),w=rep(0.3,N),inf.nn=rep(0,N),vacc.nn=rep(0,N)))

### Note there is a fn called Regenerate.g.PTN that does very similar things - if this changes
### please check to see if Regenerate.g.PTN needs changing too.

if(model=="erdos.renyi.game"){
  ### Construct the Static Preferential Transmission Network (PTN). Assume this to also be the Social Network.
  phi <- ave.degree/(N-1)
  g.PTN <- erdos.renyi.game(N, phi)
  
  model.specs <- c(model.specs,model=model)
  params.of.model <- c(params.of.model,ave.degree=ave.degree)
}

if(model=="watts.strogatz.game"){
  phi <- 0.5
  g.PTN <- watts.strogatz.game(dim=1, size=N, nei=round(ave.degree/2,0), phi)
  ### note that the simplify removes loops and multiple edges: 
  ### for low N we are thus loosing some edges.  
  
  model.specs <- c(model.specs,model=model)
  params.of.model <- c(params.of.model,ave.degree=ave.degree,phi=phi)
}

if(model=="NW.watts.strogatz.game"){
  phi <- 0.5
  g.PTN <- NW.watts.strogatz.game(dim=1,size=N,nei=round(ave.degree/2,0),phi)
  model.specs <- c(model.specs,model=model)
  params.of.model <- c(params.of.model,ave.degree=ave.degree,phi=phi)
}
 
if(model=="barabasi.game"){
  g.PTN <- barabasi.game(n=N,power=1,m=round(ave.degree/2,0),directed=FALSE)
  params.of.model <- c(params.of.model,model=model,ave.degree=ave.degree,power=1)
  phi<-NA #still need this because of saving below - CSM 12 Jan 12
  
  model.specs <- c(model.specs,model=model)
  params.of.model <- c(params.of.model,ave.degree=ave.degree,phi=phi)
}

g.PTN <- simplify(g.PTN)

g.PTN <- Initialize.All.Vertex.Attributes(g.PTN, attributes.data)
g <- g.PTN

### list of nearest neighbours (nn) on the static Social Network. 
nn.list.PTN <- get.nn.list.of.SN(g.PTN)
N.nn <- degree(g.PTN)



### Do Theoretical Percolation Analysis 
Theta.PTN <- R0.pref*(mean(N.nn^2)-mean(N.nn))/mean(N.nn)^2
pc.PTN <- 1-1/Theta.PTN

percolation.analisis <- list(Theta.PTN=Theta.PTN,pc.PTN=pc.PTN)
if(Do.Comp.Percolation.Analysis){
### Run Practical Percolation Analysis
q.table.random <- SIR.Prob.Infection.Table(model=model,N=N,ave.degree=ave.degree,R0.pref,R0.pop,eff=eff,p.seq=p.seq, 
                                    mc.perc.runs=mc.perc.runs,added.RMCN=FALSE,preferential=FALSE,verbose=verbose)

q.table.preferential <- SIR.Prob.Infection.Table(model=model,N=N,ave.degree=ave.degree,R0.pref,R0.pop,eff=eff,p.seq=p.seq, 
                                    mc.perc.runs=mc.perc.runs,added.RMCN=FALSE,preferential=TRUE,verbose=verbose)


percolation.analisis <- list(Theta.PTN=Theta.PTN,pc.PTN=pc.PTN, q.table.random=q.table.random,
                             q.table.preferential=q.table.preferential,
                             R0.pref=R0.pref,R0.pop=R0.pop,eff=eff,
                             p.seq= p.seq, mc.perc.runs=mc.perc.runs,added.RMCN=added.RMCN)
}

### Save the PTN in an R object - for post analysis.
save(g.PTN,N,phi,nn.list.PTN,percolation.analisis, file = network.file.name)
}
   }   

   #Reparametrize model if user-supplied behavioral model is valid
   if(!is.null(usbm)){
      behavioral.weights<-usbm$behavioral.weights
      Stiffness<-usbm$Stiffness
      Personal.Delta<-usbm$Personal.Delta
      behavioral.model<-"USBM"
   }
   
   #Set the behavioral model
   set.behavioral.model(behavioral.model,params.of.model,behavioral.weights,Personal.Delta,Stiffness,names.outcomes,nirm.env)

   #What time is it now?
   rtime1<-proc.time()[3]
   #DYNAMICS FILE HERE

#############################################################
###                                                       ###
###                   EVOLVE DYNAMICS:                    ###
###                                                       ###
#############################################################

if(verbose) print(paste("::EVOLVE DYNAMICS::",sep=""))

max.V.pro <- 0

if(verbose) print(paste("::Reached Season::",sep=""))
for(flu.season in 1:total.flu.seasons){
  
  if(verbose) print(as.character(flu.season))
  
  ### Reset the network back to g.PTN but keep updated attributes 
  g.PTN <- Copy.All.Vertex.Attributes(g.PTN,g)   
  
  ### Get Active Transmission Network (ATN): Deactivate bonds based on transmissibility 
  g.APTN <- get.Active.Transmission.Network(g.PTN,R0.pref)
  
  if(added.RMCN){
    ### Construct the Random Mixing Contact Network (RMCN)
    T.bond <- get.T.bond(R0.pop,N)  ### random network ave_k per node is =N
    g.RMCN  <- erdos.renyi.game(N, T.bond)
    
    ### Construct the Overall Potentially Active Contact Network
    g <- graph.union.plus.attributes(g.APTN, g.RMCN) 
  }else{g <- g.APTN}
  rm(g.APTN)
  
  ### g.cluster <- clusters(g)  ### this is not needed now but when an g.RMCN is on then maybe
 
   
  #############################################################
  ###                                                       ###
  ###                       DECISIONS:                      ###
  ###           Apply Vaccination Decisions on Network      ###
  ###                                                       ###
  #############################################################
  
  ### sample initially vaccinated
  decide.to.vacc.samp <- (runif(N,0,1) <= V(g)$w)
  if.vacc.then.effect <- (runif(N,0,1) <= eff)
  
  vacc.samp <- decide.to.vacc.samp & if.vacc.then.effect
  vacc.but.ineff.samp <- decide.to.vacc.samp & !if.vacc.then.effect
  
  susc.samp <- !vacc.samp ### these include the vacc.but.ineff.samp
  
  susceptible <- get.person.IDs(g,susc.samp)                    
  vaccinated  <- get.person.IDs(g,vacc.samp)  
  N.vacc      <- length(vaccinated)
  
  ### Get the Network of the susceptibles
  g.sub <- get.exposed.network(g,susceptible)
  N.sub <- g.sub[[1]]
  
  
  #############################################################
  ###                                                       ###
  ###                       OUTCOME:                        ###
  ###     Contruct the Cluster of those that got Infected   ###
  ###                                                       ###
  #############################################################
    
  ### Placed Initial infected on the ATN: Sample the initial infected nodes
  expected.vacc.coverage <- eff*sum(V(g)$w)/N
  initial.inf.samp <- (runif(N.sub,0,1) <= initial.inf.prop/(1-expected.vacc.coverage))
  initial.infected <- get.person.IDs(g.sub,initial.inf.samp)
  
  ### Do Connected Cluster Analysis in the ATN
  g.sub.cluster <- clusters(g.sub)
  g.sub.mem     <- g.sub.cluster$membership
  ### Map cluster Analysis of ATN to the SN
  g.mem <- rep(NA,N)
  g.mem[susc.samp] <- g.sub.mem
  g.mem[vacc.samp] <- -1
  
  ### Get all the IDs of the nodes in g.sub that belong to the same cluster as an initally infected node.
  IDs.of.infected.clusters <- unique(g.sub.mem[initial.infected])  
  inf.samp.in.g.sub <- (g.sub.mem %in% IDs.of.infected.clusters)
  
  ### Map the obtained IDs of the infected in g.sub to IDs in g
  inf.samp <- Get.Infected.samp.from.sub.g(g,susc.samp,inf.samp.in.g.sub)        
  infected <- get.person.IDs(g,inf.samp) 
  N.inf    <- length(infected)
  
  susc.samp <- (susc.samp & !inf.samp)  
  
  
  ### Note: if p=0 then in this SIR or SEIR we get R=N at t=inf. However we need to correct 
  ### based on R0 and 1/mu as it relates to T to predict what fraction of N is infected by time T.
  
  ### set the attribute that counts the number of known nn 
  ## vaccinated and infected individuals in the Social Network PTN   
  ifelse(sum(behavioral.weights[,"Local.Vacc"])>0,
  V(g)$vacc.nn <- unlist(lapply(nn.list.PTN,get.num.nn.with.att,att.samp=decide.to.vacc.samp)),
  V(g)$vacc.nn <- 0)
  
  ifelse(sum(behavioral.weights[,"Local.Inf"])>0,
  V(g)$inf.nn <- unlist(lapply(nn.list.PTN,get.num.nn.with.att,att.samp=inf.samp)),
  V(g)$inf.nn <- 0)
         
  #############################################################
  ###                                                       ###
  ###                     EVALUATION:                       ###
  ### Evaluate Chosen Strategy and Update Vaccination Prob. ###
  ###                                                       ###
  #############################################################
  
  max.V.pro <- s.mem*max.V.pro + 1
  delta <- rep(0,N)  
  eps   <- rep(0,N)
  
  ### the Behavioral.Model.R specifies these four functions below
  Local.Inf.Delta   <- get.Local.Inf.Delta(V(g)$inf.nn/N.nn)
  Local.Vacc.Delta  <- get.Local.Vacc.Delta(V(g)$vacc.nn/N.nn)
  Global.Inf.Delta  <- get.Global.Inf.Delta(N.inf/N)  
  Global.Vacc.Delta <- get.Global.Vacc.Delta(N.vacc/N) 
  
  Pop.Samp[["VaccInf"]] <- (vacc.but.ineff.samp & inf.samp) 
  Pop.Samp[["Vacc"]]    <- vacc.samp
  Pop.Samp[["Inf"]]     <- (inf.samp & !vacc.but.ineff.samp)
  Pop.Samp[["UnInf"]]   <- (!vacc.samp & !inf.samp)
  
  for(outcome in names.outcomes){
  samp <- Pop.Samp[[outcome]]
  delta[samp] <- Personal.Delta[outcome]*behavioral.weights[outcome,"Personal"]+
                 Local.Inf.Delta[samp]*behavioral.weights[outcome,"Local.Inf"]+
                 Local.Vacc.Delta[samp]*behavioral.weights[outcome,"Local.Vacc"]+
                 Global.Inf.Delta*behavioral.weights[outcome,"Global.Inf"]+
                 Global.Vacc.Delta*behavioral.weights[outcome,"Global.Vacc"]
  
  eps[samp] <- as.numeric(Stiffness[outcome])
  }


  V(g)$V <- s.mem*V(g)$V + delta 
  V(g)$w <- eps*V(g)$w + (1-eps)*V(g)$V/max.V.pro
  
  ### Change.Vacc.Prob is no longer needed but we keep to remind us of the different approach
  ###g <- Change.Vacc.Prob(g,s.mem,eps,kappa.nn,delta,max.V.pro,nn.list.PTN)
  
  #############################################################
  ###                                                       ###
  ###                      OUTPUT:                          ###
  ###                 Write to Temp File                    ###
  ###                                                       ###
  #############################################################
  
  
  ### Analyze the Network of susceptibles 
  #ddist.g.sub <- degree.distribution(g.sub, cumulative = FALSE)
  #g.sub.knn   <- graph.knn(g.sub)
  
  states=cbind(sus=susc.samp,vacc=vacc.samp,vaccinf=vacc.but.ineff.samp,
               inf=inf.samp,cluster=g.mem,w=V(g)$w)

  ### Save Temp file
  save(states, file = paste(output.dir,"TempOutput_",model,
                               "_season_",as.character(flu.season),".RData",sep=""))
  
  rm(g.sub)
  gc()
} ### end dynamics.


#############################################################
###                                                       ###
###                      OUTPUT:                          ###
###         Read Temp Output and write to one file        ###
###                                                       ###
#############################################################

rm(g,g.PTN)
gc()

if (verbose) print("::REACHED FINAL OUTPUT:: please wait a few more min")

seasonal.output <- list(NULL)

for(flu.season in 1:total.flu.seasons){
  
  load(file = paste(output.dir,"TempOutput_",model,
                    "_season_",as.character(flu.season),".RData",sep=""),e<-new.env())
  seasonal.output[[flu.season]]<- list(states=e$states)
  
}

names(seasonal.output) <- 1:total.flu.seasons

### Save Final Output Containing the Dynamics - CSM 12 JAN 12
if(save.model){
   save(params.of.model,model.specs,seasonal.output,
      file = file.name.output, compress=T,safe=T)
}

### Delete All Temp Output Files
for(flu.season in 1:total.flu.seasons){
file.remove(file = paste(output.dir,"TempOutput_",model,
                               "_season_",as.character(flu.season),".RData",sep=""))}

#############################################################
###                                                       ###
###                       NOTES:                          ###
###                                                       ###
#############################################################

### The final time comes from beta.
### Thus we may need to make beta seasonal - i.e., changing over a 6 month period and run the model in delta t = 1 month.

   #Finalizing the output for 
   #what time is it now?
   rtime2<-proc.time()[3]
   outpm<-list(Params=params.of.model,Results=seasonal.output,Runtime=rtime2-rtime1)
   class(outpm)<-"nirm"
   return(outpm)
}

print.nirm<-function(x,...){
   cat("Summary of Network Inductive Reasoning Model \n")
   cat("\t Model Parameters \n")
   cat(" Size of Network: \t",x$Params["N"],"\n")
   cat(" Network Model: \t",x$Params["model"],"\n")
   cat(" Behavioral Model: \t",x$Params["Behavioral.Model"],"\n\n")
   cat(" Number of Seasons: \t",x$Params["total.flu.seasons.tfs"],"\n")
   cat(" Initial Pr(Cond): \t",x$Params["initial.inf.prop.iip"],"\n")
   cat(" Suppressant Efficacy: \t",x$Params["eff.eff"],"\n")
   cat(" SIR Parameters: \n\t ",
      paste("beta_0=",round(as.numeric(x$Params["big.beta.pref.b0"]),3),";","Beta_0=",round(as.numeric(x$Params["big.beta.pop.B0"]),3),";","gamma=",round(as.numeric(x$Params["gamma.gamma"]),3)),"\n\n")
   
   #Define Harmonic Mean for Detecting Epidemics as H+1.96*(sd(H))
   #H.mean<-function(m){length(m)/sum(1/m)}
   #H.sd<-function(m){sqrt(sum((m-H.mean(m))^2)/length(m))}
   N<-as.numeric(x$Params["N"])
   w.per.season<-unlist(lapply(x$Results,function(x) mean(x[[1]][,"w"])))
   inc.per.season<-unlist(lapply(x$Results,function(x) sum(x[[1]][,"inf"])/N))
   cat("\t Seasonal Distributions \n") 
   cat(" E[W]\n")
   print(round(quantile(w.per.season,prob=c(0.025,.5,.975)),3))
   cat(" Incidence\n")
   print(round(quantile(inc.per.season,prob=c(0.025,.5,.975)),3))
   cat("Seasonal Correlation between E[W] and Incidence:",round(cor(w.per.season,inc.per.season),3),"\n\n")
   cat("This model took",x$Runtime, "seconds to run.\n")
   invisible(x)
}

set.behavioral.model<-function(Behavioral.Model,params.of.model,behavioral.weights,Personal.Delta,Stiffness,names.outcomes,nirm.env){
   if(Behavioral.Model=="USBM" || is.null(Behavioral.Model)){return(print("Using User-Supplied Behavioral Model"))}
   beh.env<-environment()
   
   #BEH MODELS HERE

#############################################################
###                                                       ###
###           VACCINATION BEHAVIORAL MODELS               ###
###                                                       ###
#############################################################

if(verbose) print(":: SPECIFING THE VACCINATION BEHAVIORAL MODEL ::")

if(Behavioral.Model=="Original_Personal"){
  
  ### This model uses the function Global.Vacc.Delta.Threshold in Evolve.Dynamics
  ### when computing the Global.Vacc.Delta
  behavioral.weights[c("VaccInf","Inf","UnInf"),"Personal"] <- 1
  behavioral.weights[c("Vacc"),"Global.Vacc"] <- 1
  Personal.Delta[names.outcomes] <- c(0,0.5,1,0) 
  
  Stiffness[names.outcomes] <- rep(0,length(names.outcomes))
  
  get.Local.Inf.Delta <- function(x)  {return(x)}
  get.Local.Vacc.Delta <- function(x) {return(x)}  
  get.Global.Inf.Delta <- function(x) {return(x)}
  get.Global.Vacc.Delta <- function(x){Global.Vacc.Delta.Threshold(x,pc.PTN)}
  
  model.specs <- c(model.specs,Behavioral.Model=Behavioral.Model)
  
  params.of.model <- c(params.of.model,
                       Personal.Delta=Personal.Delta,Stiffness=Stiffness)  
}

if(Behavioral.Model=="Simple_Personal"){
  behavioral.weights[c("VaccInf","Inf","UnInf"),"Personal"] <- 1
  behavioral.weights[c("Vacc"),"Global.Inf"] <- 1
  Personal.Delta[names.outcomes] <- c(0,0.5,1,0) 
  
  Stiffness[names.outcomes] <- rep(0,length(names.outcomes))
  
  get.Local.Inf.Delta <- function(x)  {return(x)}
  get.Local.Vacc.Delta <- function(x) {return(x)}  
  get.Global.Inf.Delta <- function(x) {return(x)}
  get.Global.Vacc.Delta <- function(x){return(x)}
  
  model.specs <- c(model.specs,Behavioral.Model=Behavioral.Model)
  
  params.of.model <- c(params.of.model,
                       Personal.Delta=Personal.Delta,Stiffness=Stiffness)
  
}

   #Send the model back to the nirm environment
   for(i in 1:length(ls(envir=beh.env))){
      assign(ls(envir=beh.env)[i],get(ls(envir=beh.env)[i]),envir=nirm.env)
   }
}

   #FUNCTIONS HERE

all.to.all.game <-
function (N) 
{
    return(erdos.renyi.game(N, 1))
}
assign.global.parametes <-
function (dummy, type) 
{
    rr <- NULL
    if (type == "num") {
        for (ii in 1:length(names(dummy))) {
            rr <- c(rr, parse(text = paste(names(dummy[ii]), 
                "<- as.numeric(", deparse(substitute(dummy)), 
                "[", as.character(ii), "])", sep = "")))
        }
    }
    else {
        for (ii in 1:length(names(dummy))) {
            rr <- c(rr, parse(text = paste(names(dummy[ii]), 
                "<- ", deparse(substitute(dummy)), "[", as.character(ii), 
                "]", sep = "")))
        }
    }
    return(rr)
}
BA.scale.free.game <-
function (size, ave.degree) 
{
    g1 <- simplify(barabasi.game(n = size, power = 1, m = ave.degree/2, 
        directed = FALSE))
    return(g1)
}
Change.Vacc.Prob <-
function (g, s.mem, eps, kappa.nn, delta, normalizing.factor, 
    nn.list.SN) 
{
    V(g)$V <- s.mem * V(g)$V + delta
    V(g)$w <- eps * V(g)$w + (1 - eps) * V(g)$V/normalizing.factor
    if (kappa.nn > 1 | kappa.nn < 0) 
        stop("kappa out of range")
    if (kappa.nn < 1) {
        V(g)$ave.nn.w <- unlist(lapply(nn.list.SN, get.ave.X.over.nn, 
            X.values = V(g)$w))
        V(g)$w <- kappa.nn * V(g)$w + (1 - kappa.nn) * V(g)$ave.nn.w
    }
    return(g)
}
Copy.All.Vertex.Attributes <-
function (g.to, g.from) 
{
    for (i in list.vertex.attributes(g.from)) {
        g.to <- set.vertex.attribute(g.to, i, index = V(g.to), 
            get.vertex.attribute(g.from, i, index = V(g.from)))
    }
    return(g.to)
}
do.w.k.correlation <-
function (x, y, w, add.char = NULL) 
{
    R <- NULL
    names.x <- colnames(x)
    names.y <- colnames(y)
    names.R <- NULL
    if (!is.null(add.char)) 
        add.char <- paste("_", add.char, sep = "")
    for (nx in names.x) {
        samp <- as.logical(x[, nx])
        w.samp <- w[samp]
        for (ny in names.y) {
            y.samp <- y[samp, ny]
            cor.out <- NA
            if (length(samp) > 0) 
                cor.out <- cor(w.samp, y.samp)
            R <- c(R, cor.out)
            names.R <- c(names.R, paste("cor_", nx, "_", ny, 
                add.char, sep = ""))
        }
    }
    names(R) <- names.R
    return(R)
}
generate.distribution <-
function (x) 
{
    dummy <- table(x)
    dummy <- dummy/sum(dummy)
    mm <- max(as.numeric(names(dummy)))
    dummy.range <- 1:mm
    dummy.table <- rep(0, mm)
    dummy.table[as.numeric(names(dummy))] <- dummy
    return(dummy.table)
}
generate.knnk <-
function (tab, samp) 
{
    split.tab <- split(tab[samp, ], as.factor(tab[samp, "d"]))
    knnk <- sapply(split.tab, mean)["knn", ]
    mm <- max(as.numeric(names(knnk)))
    rr <- 1:mm
    r <- rep(NaN, mm)
    r[as.numeric(names(knnk))] <- as.numeric(knnk)
    return(r)
}
get.Active.Transmission.Network <-
function (g, R0) 
{
    n.bonds <- length(E(g))
    n.verticies <- g[[1]]
    T.bond <- get.T.bond(R0, 2 * n.bonds/n.verticies)
    active.bonds.samp <- (runif(n.bonds, 0, 1) <= T.bond)
    g.sub <- delete.edges(g, E(g)[!active.bonds.samp])
    return(g.sub)
}
get.ave.X.over.nn <-
function (nn.list.element, X.values) 
{
    return(mean(X.values[nn.list.element + 1]))
}
get.exposed.network <-
function (g, x) 
{
    if (is.logical(x)) 
        x <- get.person.IDs(g, x)
    return(subgraph(g, x))
}
Get.Infected.ID.from.sub.g <-
function (g, s.samp.in.g, inf.samp.in.g.sub) 
{
    Map.g.sub <- cbind(g = get.person.IDs(g), g.sub = NA)
    Map.g.sub[s.samp.in.g, "g.sub"] <- c(1:sum(s.samp.in.g)) - 
        1
    infected.in.g.sub <- get.person.IDs(g, inf.samp.in.g.sub)
    infected.in.g <- Map.g.sub[Map.g.sub[, "g.sub"] %in% infected.in.g.sub, 
        "g"]
    return(infected.in.g)
}
Get.Infected.samp.from.sub.g <-
function (g, s.samp.in.g, inf.samp.in.g.sub) 
{
    Map.g.sub <- cbind(g = get.person.IDs(g), g.sub = NA)
    Map.g.sub[s.samp.in.g, "g.sub"] <- c(1:sum(s.samp.in.g)) - 
        1
    infected.in.g.sub <- get.person.IDs(g, inf.samp.in.g.sub)
    infected.samp <- (Map.g.sub[, "g.sub"] %in% infected.in.g.sub)
    return(infected.samp)
}
get.likelihood.surrounded.by.similars <-
function (samp, normalizied.wrt, g, g.k = NULL) 
{
    if (is.null(g.k)) 
        g.k <- degree(g)
    g.k.samp <- g.k[samp]
    g.sub <- get.exposed.network(g, samp)
    g.k.sub <- degree(g.sub)
    x <- g.k.sub/g.k.samp
    m <- mean(x)/normalizied.wrt
    s <- sd(x)/normalizied.wrt
    return(c(mean = m, sd = s))
}
get.nn.list.of.SN <-
function (g, k = 1) 
{
    x <- neighborhood(g, order = k, nodes = V(g))
    r <- lapply(x, FUN = function(y) return(y[-1]))
    return(r)
}
get.num.nn.with.att <-
function (x, att.samp) 
{
    num.positives <- sum(att.samp[x + 1])
    return(num.positives)
}
get.person.IDs <-
function (g, samp = TRUE) 
{
    return(V(g)[samp])
}
get.T.bond <-
function (R0, ave_k) 
{
    T <- R0/ave_k
    if (R0 > ave_k) 
        T <- 1
    return(T)
}
get.times.between.spikes <-
function (time.series, th = 0.55) 
{
    x <- abs(diff(time.series))
    threshold <- th * max(x)
    length.time.series <- length(x)
    peaks <- c(1:length.time.series)[x > threshold]
    intervals.between.peaks <- diff(peaks)
    return(intervals.between.peaks)
}
Global.Vacc.Delta.Threshold <-
function (p, p_c) 
{
    if (p < p_c) {
        return(1)
    }
    return(0)
}
graph.union.plus.attributes <-
function (g.att, g.no.att) 
{
    g <- graph.union(g.att, g.no.att)
    for (i in list.vertex.attributes(g.att)) {
        g <- set.vertex.attribute(g, i, index = V(g), get.vertex.attribute(g.att, 
            i, index = V(g.att)))
    }
    return(g)
}
Initialize.All.Vertex.Attributes <-
function (g, attributes.data) 
{
    for (i in colnames(attributes.data)) {
        g <- set.vertex.attribute(g, i, index = V(g), attributes.data[, 
            i])
    }
    return(g)
}
map.to.full.g <-
function (samp, v.g.sub, v.not.g.sub) 
{
    N <- length(samp)
    R <- v.not.g.sub * c(1:N)
    R[samp] <- v.g.sub
    return(R)
}
NW.watts.strogatz.game <-
function (dimension, size, nei, phi) 
{
    g1 <- erdos.renyi.game(N, 2 * phi * nei/(size - 1))
    g2 <- simplify(watts.strogatz.game(dim = dimension, size = size, 
        nei = round(nei * (1 - phi), 0), 0))
    g3 <- simplify(graph.union(g1, g2))
    return(g3)
}
plot.Global.Dynamics <-
function (Dyn, file.name, title = NULL, legend = NULL, height = 6, 
    width = 12) 
{
    col.seq <- c("lightblue", "palevioletred", "darkgreen")
    plot(Dyn$year, Dyn$s, xlab = "year", ylab = "p", main = title, 
        ylim = c(0, 1), type = "l", col = col.seq[1], lwd = 3, 
        cex = 1, cex.axis = 1, cex.lab = 1, cex.main = 1)
    points(Dyn$year, Dyn$i, type = "l", col = col.seq[2], lwd = 3)
    points(Dyn$year, Dyn$p, type = "l", col = col.seq[3], lwd = 3)
    grid(5, 5, col = "lightgray", lty = "dotted", lwd = par("lwd"), 
        equilogs = TRUE)
    if (!is.null(legend)) {
        labels <- c("s: uninfected", "i: infected", "p: coverage")
        legend(Dyn[nrow(Dyn), "year"] * 0.8, 1, labels, lwd = 3, 
            col = col.seq, text.width = 0.4, border = NULL)
    }
    dev.copy(pdf, file.name, height = height, width = width)
    dev.off()
    return(NULL)
}
plot.individual.w.dyn <-
function (seasonal.output, N, focus.years = c(10, 40, 80), file.name, 
    height = 4, width = 8) 
{
    if (length(focus.years) != 3) {
        stop("plot.individual.w.dyn problem with focus.years input")
    }
    lower <- focus.years[1]
    mid <- focus.years[2]
    upper <- focus.years[3]
    years <- c(lower:upper)
    temp <- cbind(c(1:N), seasonal.output[[lower]]$states[, "w"], 
        seasonal.output[[mid]]$states[, "w"], seasonal.output[[upper]]$states[, 
            "w"])
    xx <- subset(temp, temp[, 2] < 0.01 & temp[, 3] > 0.99 & 
        temp[, 4] < 0.01)
    yy <- subset(temp, temp[, 2] > 0.98 & temp[, 3] < 0.01 & 
        temp[, 4] > 0.99)
    if (length(xx) * length(yy) < 1) {
        stop("plot.individual.w.dyn no one found with specified tolerance")
    }
    id1 <- xx[1, 1]
    id2 <- yy[1, 1]
    w1 <- sapply(seasonal.output, FUN = function(x, pos) {
        x$states[pos, "w"]
    }, pos = id1)
    w2 <- sapply(seasonal.output, FUN = function(x, pos) {
        x$states[pos, "w"]
    }, pos = id2)
    plot(years, w1[years], xlab = "year", ylab = expression(w^(i)), 
        main = NULL, ylim = c(0, 1), type = "l", col = "darkgreen", 
        lwd = 3, cex = 1, cex.axis = 1, cex.lab = 1, cex.main = 1)
    points(years, w2[years], type = "l", col = "brown", lwd = 3)
    dev.copy(pdf, file.name, height = height, width = width)
    dev.off()
    return(NULL)
}
plot.Percolation.Analysis <-
function (percolation.analisis, file.name, title = NULL, Dyn = NULL, 
    height = 6, width = 7.5) 
{
    col.seq <- c("red", "blue", "darkgreen")
    x <- cbind(percolation.analisis$p.seq, SIR.ODE(times = seq(1, 
        200, 0.1), percolation.analisis$p.seq, percolation.analisis$R0.pref, 
        N))
    plot(x[, 1], x[, 2], xlab = "p", ylab = "q(p)", main = title, 
        ylim = c(0, 1), type = "l", col = col.seq[1], lwd = 5, 
        cex = 1, cex.axis = 1, cex.lab = 1, cex.main = 1)
    x <- percolation.analisis$q.table.random
    points(x[, "p"], x[, "q(p)"], type = "l", col = col.seq[2], 
        lwd = 3)
    x <- percolation.analisis$q.table.preferential
    points(x[, "p"], x[, "q(p)"], type = "l", col = col.seq[3], 
        lwd = 3)
    if (is.null(Dyn)) {
        labels <- c("SIR ODE", "random vaccination", "targeted vaccination")
    }
    else {
        labels <- c("SIR ODE", "random vaccination", "targeted vaccination", 
            "behavior")
        col.seq <- c(col.seq, "black")
        Dyn <- Dyn[order(Dyn$p), ]
        points(Dyn$p, Dyn$i, type = "o", lty = 2, col = col.seq[4])
    }
    grid(5, 5, col = "lightgray", lty = "dotted", lwd = par("lwd"), 
        equilogs = TRUE)
    legend(0.55, 1, labels, lwd = 3, col = col.seq, text.width = 0.35, 
        border = NULL)
    dev.copy(pdf, file.name, height = height, width = width)
    dev.off()
    return(NULL)
}
plot.Vacc.Prob.Dist <-
function (dist.w, num.breaks, histo.mids, years = 1, file.name, 
    height = 6, width = 7.5) 
{
    focus.year <- years[1]
    plot(histo.mids, log(num.breaks * dist.w[focus.year, paste("w.hist", 
        histo.mids, sep = "")], 10), type = "o", lty = 2, col = "black", 
        pch = 18, yaxt = "n", panel.first = abline(v = c(0:5)/5, 
            h = c(-3:1), col = "lightgray", lty = "dotted", lwd = par("lwd")), 
        xlab = expression(w^(i)), ylab = expression(rho(w^(i))))
    par(las = 1)
    axis(2, at = c(-3:1), labels = c(quote(10^-3), quote(10^-2), 
        quote(10^-1), expression(1), quote(10^1)))
    if (length(years) > 1) {
        for (focus.year in years[-1]) {
            points(histo.mids, log(num.breaks * dist.w[focus.year, 
                paste("w.hist", histo.mids, sep = "")], 10), 
                type = "o", lty = 2, col = "darkgreen")
        }
    }
    dev.copy(pdf, file.name, height = height, width = width)
    dev.off()
    return(NULL)
}
Regenerate.g.PTN <-
function (model, N, ave.degree) 
{
    if (model == "erdos.renyi.game") {
        phi <- ave.degree/(N - 1)
        g.PTN <- erdos.renyi.game(N, phi)
    }
    if (model == "watts.strogatz.game") {
        phi <- 0.5
        g.PTN <- watts.strogatz.game(dim = 1, size = N, nei = round(ave.degree/2, 
            0), phi)
    }
    if (model == "NW.watts.strogatz.game") {
        phi <- 0.5
        g.PTN <- NW.watts.strogatz.game(dim = 1, size = N, nei = round(ave.degree/2, 
            0), phi)
    }
    if (model == "barabasi.game") {
        g.PTN <- barabasi.game(n = N, power = 1, m = round(ave.degree/2, 
            0), directed = FALSE)
        params.of.model <- c(params.of.model, model = model, 
            ave.degree = ave.degree, power = 1)
    }
    g.PTN <- simplify(g.PTN)
    return(g.PTN)
}
SIR.ODE <-
function (times, p.seq, R0, N) 
{
    Y <- NULL
    prob <- NULL
    for (p in p.seq) {
        Y["S"] <- ((1 - p) * N - ifelse(p < 1, 1, 0))/N
        Y["I"] <- ifelse(p < 1, 1, 0)/N
        Y["R"] <- 0
        out <- ode(Y, times, SIR.ODE.model, R0)
        prob <- c(prob, as.numeric(out[nrow(out), "R"]))
    }
    return(prob)
}
SIR.ODE.model <-
function (t, Y, R0) 
{
    S <- Y[1]
    I <- Y[2]
    R <- Y[3]
    dS <- -R0 * S * I
    dI <- R0 * S * I - I
    dR <- I
    return(list(c(dS = dS, dI = dI, dR = dR)))
}
SIR.Prob.Infection.Table <-
function (model, N, ave.degree, R0.pref, R0.pop, eff = 1, p.seq = c(0:100)/100, 
    mc.perc.runs = 100, added.RMCN = FALSE, preferential = FALSE, 
    verbose = FALSE) 
{
    q.table <- matrix(0, nrow = length(p.seq), ncol = 3, dimnames = list(p.seq, 
        c("p", "q(p)", "Var[q(p)]")))
    if (verbose) {
        print("Running SIR.Prob.Infection.Table.R")
        if (preferential) {
            print("Preferential/Targeted  Vaccination")
        }
        else {
            print("Random  Vaccination")
        }
    }
    for (p in p.seq) {
        if (verbose) {
            print(paste("::p=", p, sep = ""))
        }
        q.dummy <- 0
        q2.dummy <- 0
        for (mc.run in 1:mc.perc.runs) {
            g <- Regenerate.g.PTN(model, N, ave.degree)
            if (preferential) {
                N.nn <- degree(g)
                N.nn.id <- cbind(1:N, N.nn)
                N.nn.id <- N.nn.id[order(N.nn.id[, 2], decreasing = TRUE), 
                  ]
            }
            g.APTN <- get.Active.Transmission.Network(g, R0.pref)
            if (added.RMCN) {
                T.bond <- get.T.bond(R0.pop, N)
                g.RMCN <- erdos.renyi.game(N, T.bond)
                g <- graph.union.plus.attributes(g.APTN, g.RMCN)
            }
            else {
                g <- g.APTN
            }
            rm(g.APTN)
            if (!preferential) {
                decide.to.vacc.samp <- (runif(N, 0, 1) <= p)
            }
            if (preferential) {
                decide.to.vacc.samp <- rep(FALSE, N)
                decide.to.vacc.samp[N.nn.id[1:round(p * N, 0), 
                  1]] <- TRUE
            }
            if.vacc.then.effect <- (runif(N, 0, 1) <= eff)
            expected.vacc.coverage <- p
            vacc.samp <- decide.to.vacc.samp & if.vacc.then.effect
            vacc.but.ineff.samp <- decide.to.vacc.samp & !if.vacc.then.effect
            susc.samp <- !vacc.samp
            susceptible <- get.person.IDs(g, susc.samp)
            vaccinated <- get.person.IDs(g, vacc.samp)
            N.vacc <- length(vaccinated)
            g.sub <- get.exposed.network(g, susceptible)
            N.sub <- g.sub[[1]]
            initial.inf.samp <- (runif(N.sub, 0, 1) <= initial.inf.prop/(1 - 
                expected.vacc.coverage))
            initial.infected <- get.person.IDs(g.sub, initial.inf.samp)
            g.sub.cluster <- clusters(g.sub)
            g.sub.mem <- g.sub.cluster$membership
            g.mem <- rep(NA, N)
            g.mem[susc.samp] <- g.sub.mem
            g.mem[vacc.samp] <- -1
            IDs.of.infected.clusters <- unique(g.sub.mem[initial.infected])
            inf.samp.in.g.sub <- (g.sub.mem %in% IDs.of.infected.clusters)
            inf.samp <- Get.Infected.samp.from.sub.g(g, susc.samp, 
                inf.samp.in.g.sub)
            infected <- get.person.IDs(g, inf.samp)
            N.inf <- length(infected)
            q.dummy <- q.dummy + N.inf/N
            q2.dummy <- q2.dummy + (N.inf/N)^2
            susc.samp <- (susc.samp & !inf.samp)
            rm(g.sub)
            gc()
        }
        q.dummy <- q.dummy/mc.perc.runs
        q2.dummy <- q2.dummy/mc.perc.runs
        q.table[as.character(p), ] <- c(p, q.dummy, q2.dummy - 
            q.dummy^2)
    }
    return(q.table)
}
#EOF
